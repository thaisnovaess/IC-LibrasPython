# TASK-16 — Separar treino validacao e teste

- **Estado inicial:** não iniciada.
- **Etapa:** 4 de 6.
- **Dependências diretas:** [TASK-15](TASK-15.md)
- **Projeto:** IC-LibrasPython.

## Instrução para o Copilot

Execute somente esta task. Leia este arquivo inteiro, as instruções vigentes do repositório e os arquivos relevantes antes de editar. Consulte as dependências apenas para compreender contratos e verificar entregas; não execute outras tasks automaticamente.

O projeto original contém `main.py`, `database/db.py`, `camera/hand_tracking.py`, `ver_dados.py` e `teste_sqlite.py`. `camera/face_tracking.py`, `funcoes/helpers.py` e `models/model.py` estavam vazios. Na versão inicial há coleta de landmarks com OpenCV/MediaPipe e SQLite, sem classificador próprio. As tasks anteriores podem ter alterado essa estrutura: inspecione o estado atual e reutilize o que já existe.

Se uma dependência obrigatória não estiver implementada ou faltar uma decisão humana necessária, realize apenas o trabalho independente útil desta task, registre precisamente o bloqueio e pare. Não implemente a dependência por conta própria nem declare conclusão. Não peça confirmação para decisões técnicas rotineiras dentro deste escopo.

## Objetivo

Criar divisão reproduzível sem vazamento entre grupos.

## Arquivos e entregáveis previstos

módulo de split; manifests versionados; docs/divisao-dataset.md.

Esses caminhos são referências relativas à raiz do projeto. Preserve a organização já adotada por tasks concluídas. Edite somente arquivos necessários para esta entrega e a integração mínima indicada; justifique novos caminhos no resumo final. Não sobrescreva trabalho preexistente nem substitua módulos inteiros sem necessidade.

## Atividades autorizadas

1. Usar a meta da task 03 para escolher agrupamento; preferir participantes exclusivos por conjunto para avaliar generalização entre pessoas.
2. Garantir que uma gravação e suas derivações pertençam a um único conjunto.
3. Gerar manifest com IDs, grupos, semente, proporções e versão/hash do inventário.
4. Verificar cobertura de classes e quantidade de grupos; interromper com diagnóstico se a divisão viável não existir.
5. Ajustar estatísticas necessárias do pré-processamento exclusivamente no treino.

## Critérios de aceite

- [ ] Conjuntos não compartilham grupos conforme protocolo.
- [ ] Split pode ser reproduzido.
- [ ] Teste permanece separado para avaliação final.
- [ ] Insuficiência de dados é relatada sem mudar silenciosamente o protocolo.

## Validação

Asserções de disjunção de grupos e amostras, cobertura e repetibilidade; falha controlada com grupos insuficientes.

Use dados temporários/sintéticos para verificar lógica quando apropriado e identifique-os como tal. Nunca apresente esses dados como evidência de qualidade do reconhecimento. Não substitua bancos ou amostras reais. Se câmera, dependências, modelo, participantes ou ambiente não estiverem disponíveis, informe quais verificações ficaram pendentes.

## Fora do escopo

Não copiar amostras entre conjuntos nem aumentar dados antes do split.

Não iniciar a próxima task, adicionar requisitos não solicitados, publicar arquivos, executar push ou instalar dependências globalmente. Não remover dados reais. A documentação local mínima e os testes diretamente necessários à entrega estão autorizados; mudanças amplas ficam para suas tasks próprias.

## Encerramento obrigatório

Ao terminar, apresente:

1. O que foi implementado ou documentado nesta task.
2. Lista dos arquivos criados ou alterados e motivo.
3. Comandos/verificações executados e resultados reais.
4. Critérios de aceite cumpridos e pendentes.
5. Bloqueios, decisões humanas ou validações de hardware ainda necessários.

Atualize apenas o estado e os checkboxes desta task com base nas evidências. Use `concluída`, `parcial — validação pendente` ou `bloqueada`, conforme o resultado. Pare depois desse resumo e aguarde nova solicitação. Não marque tasks dependentes como concluídas.
