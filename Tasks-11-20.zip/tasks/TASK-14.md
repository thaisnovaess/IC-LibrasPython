# TASK-14 — Definir protocolo e coletar dataset

- **Estado inicial:** não iniciada.
- **Etapa:** 3 de 6.
- **Dependências diretas:** [TASK-01](TASK-01.md), [TASK-03](TASK-03.md), [TASK-13](TASK-13.md)
- **Projeto:** IC-LibrasPython.

## Instrução para o Copilot

Execute somente esta task. Leia este arquivo inteiro, as instruções vigentes do repositório e os arquivos relevantes antes de editar. Consulte as dependências apenas para compreender contratos e verificar entregas; não execute outras tasks automaticamente.

O projeto original contém `main.py`, `database/db.py`, `camera/hand_tracking.py`, `ver_dados.py` e `teste_sqlite.py`. `camera/face_tracking.py`, `funcoes/helpers.py` e `models/model.py` estavam vazios. Na versão inicial há coleta de landmarks com OpenCV/MediaPipe e SQLite, sem classificador próprio. As tasks anteriores podem ter alterado essa estrutura: inspecione o estado atual e reutilize o que já existe.

Se uma dependência obrigatória não estiver implementada ou faltar uma decisão humana necessária, realize apenas o trabalho independente útil desta task, registre precisamente o bloqueio e pare. Não implemente a dependência por conta própria nem declare conclusão. Não peça confirmação para decisões técnicas rotineiras dentro deste escopo.

## Objetivo

Produzir um dataset real revisado e documentado.

## Arquivos e entregáveis previstos

docs/protocolo-coleta.md; docs/relatorio-coleta.md; comandos de inventário se necessários.

Esses caminhos são referências relativas à raiz do projeto. Preserve a organização já adotada por tasks concluídas. Edite somente arquivos necessários para esta entrega e a integração mínima indicada; justifique novos caminhos no resumo final. Não sobrescreva trabalho preexistente nem substitua módulos inteiros sem necessidade.

## Atividades autorizadas

1. Definir instruções, enquadramento, identificação pseudônima, sessões, condições e critérios de descarte.
2. Propor quantidade inicial por sinal/participante e registrar que suficiência será avaliada experimentalmente.
3. Incluir diferentes sessões e pessoas; coletar situações sem sinal válido para avaliar rejeição.
4. Documentar autorização de participação, finalidade, acesso e retenção dos dados conforme orientação institucional.
5. Gerar inventário real por classe, participante, sessão e qualidade; orientar o responsável a executar as coletas.
6. Não criar dados sintéticos para substituir evidência real nem afirmar que pessoas participaram sem registro.

## Critérios de aceite

- [ ] Protocolo aprovado e disponível.
- [ ] Dataset real possui revisão e inventário.
- [ ] Pendência de coleta humana impede marcar a task como concluída.

## Validação

Verificar inventário a partir do banco; distinguir exemplos de relatório de resultados reais. Esta task exige participação humana.

Use dados temporários/sintéticos para verificar lógica quando apropriado e identifique-os como tal. Nunca apresente esses dados como evidência de qualidade do reconhecimento. Não substitua bancos ou amostras reais. Se câmera, dependências, modelo, participantes ou ambiente não estiverem disponíveis, informe quais verificações ficaram pendentes.

## Fora do escopo

Não treinar, publicar dataset ou contatar participantes automaticamente.

Não iniciar a próxima task, adicionar requisitos não solicitados, publicar arquivos, executar push ou instalar dependências globalmente. Não remover dados reais. A documentação local mínima e os testes diretamente necessários à entrega estão autorizados; mudanças amplas ficam para suas tasks próprias.

## Encerramento obrigatório

Ao terminar, apresente:

1. O que foi implementado ou documentado nesta task.
2. Lista dos arquivos criados ou alterados e motivo.
3. Comandos/verificações executados e resultados reais.
4. Critérios de aceite cumpridos e pendentes.
5. Bloqueios, decisões humanas ou validações de hardware ainda necessários.

Atualize apenas o estado e os checkboxes desta task com base nas evidências. Use `concluída`, `parcial — validação pendente` ou `bloqueada`, conforme o resultado. Pare depois desse resumo e aguarde nova solicitação. Não marque tasks dependentes como concluídas.
