# TASK-15 — Implementar preparação do dataset

- **Estado inicial:** não iniciada.
- **Etapa:** 4 de 6.
- **Dependências diretas:** [TASK-14](TASK-14.md)
- **Projeto:** IC-LibrasPython.

## Instrução para o Copilot

Execute somente esta task. Leia este arquivo inteiro, as instruções vigentes do repositório e os arquivos relevantes antes de editar. Consulte as dependências apenas para compreender contratos e verificar entregas; não execute outras tasks automaticamente.

O projeto original contém `main.py`, `database/db.py`, `camera/hand_tracking.py`, `ver_dados.py` e `teste_sqlite.py`. `camera/face_tracking.py`, `funcoes/helpers.py` e `models/model.py` estavam vazios. Na versão inicial há coleta de landmarks com OpenCV/MediaPipe e SQLite, sem classificador próprio. As tasks anteriores podem ter alterado essa estrutura: inspecione o estado atual e reutilize o que já existe.

Se uma dependência obrigatória não estiver implementada ou faltar uma decisão humana necessária, realize apenas o trabalho independente útil desta task, registre precisamente o bloqueio e pare. Não implemente a dependência por conta própria nem declare conclusão. Não peça confirmação para decisões técnicas rotineiras dentro deste escopo.

## Objetivo

Converter amostras revisadas em entradas numéricas consistentes.

## Arquivos e entregáveis previstos

data/ ou módulo equivalente; docs/contrato-dataset.md.

Esses caminhos são referências relativas à raiz do projeto. Preserve a organização já adotada por tasks concluídas. Edite somente arquivos necessários para esta entrega e a integração mínima indicada; justifique novos caminhos no resumo final. Não sobrescreva trabalho preexistente nem substitua módulos inteiros sem necessidade.

## Atividades autorizadas

1. Definir contrato versionado: sequência T x F, ordem de features, máscaras, rótulo e metadados de agrupamento separados.
2. Ler somente amostras elegíveis e ordenar frames, modalidades e landmarks.
3. Implementar normalização que preserve posições relativas necessárias; validar a regra com requisitos dos sinais.
4. Definir padding/truncamento ou reamostragem temporal e tratamento explícito de ausências.
5. Não ajustar estatísticas globais antes do split; expor fit/transform quando necessário para ajuste só no treino.
6. Reutilizar funções puras posteriormente na inferência; fornecer comando de exportação e relatório de rejeições.

## Critérios de aceite

- [ ] Mesma amostra gera a mesma entrada.
- [ ] IDs e rótulos não entram como coordenadas.
- [ ] Máscaras distinguem ausência de coordenada zero.
- [ ] Formato e versão estão documentados.

## Validação

Fixtures com durações distintas, mãos ausentes e ordem embaralhada; verificar dimensões, finitude e determinismo.

Use dados temporários/sintéticos para verificar lógica quando apropriado e identifique-os como tal. Nunca apresente esses dados como evidência de qualidade do reconhecimento. Não substitua bancos ou amostras reais. Se câmera, dependências, modelo, participantes ou ambiente não estiverem disponíveis, informe quais verificações ficaram pendentes.

## Fora do escopo

Não dividir dataset, treinar ou escolher parâmetros olhando resultados do teste.

Não iniciar a próxima task, adicionar requisitos não solicitados, publicar arquivos, executar push ou instalar dependências globalmente. Não remover dados reais. A documentação local mínima e os testes diretamente necessários à entrega estão autorizados; mudanças amplas ficam para suas tasks próprias.

## Encerramento obrigatório

Ao terminar, apresente:

1. O que foi implementado ou documentado nesta task.
2. Lista dos arquivos criados ou alterados e motivo.
3. Comandos/verificações executados e resultados reais.
4. Critérios de aceite cumpridos e pendentes.
5. Bloqueios, decisões humanas ou validações de hardware ainda necessários.

Atualize apenas o estado e os checkboxes desta task com base nas evidências. Use `concluída`, `parcial — validação pendente` ou `bloqueada`, conforme o resultado. Pare depois desse resumo e aguarde nova solicitação. Não marque tasks dependentes como concluídas.
