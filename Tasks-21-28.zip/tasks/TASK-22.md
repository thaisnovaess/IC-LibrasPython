# TASK-22 — Integrar inferencia a webcam

- **Estado inicial:** não iniciada.
- **Etapa:** 5 de 6.
- **Dependências diretas:** [TASK-21](TASK-21.md), [TASK-12](TASK-12.md)
- **Projeto:** IC-LibrasPython.

## Instrução para o Copilot

Execute somente esta task. Leia este arquivo inteiro, as instruções vigentes do repositório e os arquivos relevantes antes de editar. Consulte as dependências apenas para compreender contratos e verificar entregas; não execute outras tasks automaticamente.

O projeto original contém `main.py`, `database/db.py`, `camera/hand_tracking.py`, `ver_dados.py` e `teste_sqlite.py`. `camera/face_tracking.py`, `funcoes/helpers.py` e `models/model.py` estavam vazios. Na versão inicial há coleta de landmarks com OpenCV/MediaPipe e SQLite, sem classificador próprio. As tasks anteriores podem ter alterado essa estrutura: inspecione o estado atual e reutilize o que já existe.

Se uma dependência obrigatória não estiver implementada ou faltar uma decisão humana necessária, realize apenas o trabalho independente útil desta task, registre precisamente o bloqueio e pare. Não implemente a dependência por conta própria nem declare conclusão. Não peça confirmação para decisões técnicas rotineiras dentro deste escopo.

## Objetivo

Reconhecer uma execução capturada ao vivo usando início e fim manuais.

## Arquivos e entregáveis previstos

orquestração de reconhecimento; buffer temporal; comandos de execução.

Esses caminhos são referências relativas à raiz do projeto. Preserve a organização já adotada por tasks concluídas. Edite somente arquivos necessários para esta entrega e a integração mínima indicada; justifique novos caminhos no resumo final. Não sobrescreva trabalho preexistente nem substitua módulos inteiros sem necessidade.

## Atividades autorizadas

1. Adicionar modo reconhecimento separado da coleta de dataset.
2. Usar o fluxo aprovado na task 03: iniciar captura, executar um sinal e finalizar para inferir.
3. Manter buffer limitado por duração/tamanho configurado e preservar frames ausentes.
4. Manter visualização responsiva; se houver worker, definir fila limitada, cancelamento e encerramento limpo.
5. Não persistir reconhecimento como dado de treino automaticamente.
6. Informar falta de modelo, sequência curta e limite de duração conforme contrato.

## Critérios de aceite

- [ ] Uma captura manual gera uma chamada de inferência.
- [ ] Buffer não cresce indefinidamente.
- [ ] Câmera pode ser encerrada sem processo pendurado.
- [ ] Modo coleta continua funcionando.

## Validação

Simular sequência e limites sem câmera; realizar smoke test com webcam quando disponível, registrando pendências.

Use dados temporários/sintéticos para verificar lógica quando apropriado e identifique-os como tal. Nunca apresente esses dados como evidência de qualidade do reconhecimento. Não substitua bancos ou amostras reais. Se câmera, dependências, modelo, participantes ou ambiente não estiverem disponíveis, informe quais verificações ficaram pendentes.

## Fora do escopo

Não implementar segmentação automática, tradução contínua ou interface final.

Não iniciar a próxima task, adicionar requisitos não solicitados, publicar arquivos, executar push ou instalar dependências globalmente. Não remover dados reais. A documentação local mínima e os testes diretamente necessários à entrega estão autorizados; mudanças amplas ficam para suas tasks próprias.

## Encerramento obrigatório

Ao terminar, apresente:

1. O que foi implementado ou documentado nesta task.
2. Lista dos arquivos criados ou alterados e motivo.
3. Comandos/verificações executados e resultados reais.
4. Critérios de aceite cumpridos e pendentes.
5. Bloqueios, decisões humanas ou validações de hardware ainda necessários.

Atualize apenas o estado e os checkboxes desta task com base nas evidências. Use `concluída`, `parcial — validação pendente` ou `bloqueada`, conforme o resultado. Pare depois desse resumo e aguarde nova solicitação. Não marque tasks dependentes como concluídas.
