# TASK-27 — Preparar distribuicao

- **Estado inicial:** não iniciada.
- **Etapa:** 6 de 6.
- **Dependências diretas:** [TASK-26](TASK-26.md)
- **Projeto:** IC-LibrasPython.

## Instrução para o Copilot

Execute somente esta task. Leia este arquivo inteiro, as instruções vigentes do repositório e os arquivos relevantes antes de editar. Consulte as dependências apenas para compreender contratos e verificar entregas; não execute outras tasks automaticamente.

O projeto original contém `main.py`, `database/db.py`, `camera/hand_tracking.py`, `ver_dados.py` e `teste_sqlite.py`. `camera/face_tracking.py`, `funcoes/helpers.py` e `models/model.py` estavam vazios. Na versão inicial há coleta de landmarks com OpenCV/MediaPipe e SQLite, sem classificador próprio. As tasks anteriores podem ter alterado essa estrutura: inspecione o estado atual e reutilize o que já existe.

Se uma dependência obrigatória não estiver implementada ou faltar uma decisão humana necessária, realize apenas o trabalho independente útil desta task, registre precisamente o bloqueio e pare. Não implemente a dependência por conta própria nem declare conclusão. Não peça confirmação para decisões técnicas rotineiras dentro deste escopo.

## Objetivo

Permitir executar a aplicação em outra máquina.

## Arquivos e entregáveis previstos

scripts de instalação/empacotamento; docs/instalacao.md; configuração de distribuição.

Esses caminhos são referências relativas à raiz do projeto. Preserve a organização já adotada por tasks concluídas. Edite somente arquivos necessários para esta entrega e a integração mínima indicada; justifique novos caminhos no resumo final. Não sobrescreva trabalho preexistente nem substitua módulos inteiros sem necessidade.

## Atividades autorizadas

1. Confirmar sistema alvo; começar por instalação documentada em ambiente Python salvo requisito de executável aprovado.
2. Incluir dependências e pacote de inferência aprovado, respeitando licenças de terceiros.
3. Separar recursos da aplicação de dados graváveis e ajustar configuração com migração não destrutiva se necessário.
4. Excluir banco de participantes, logs privados e datasets do pacote padrão.
5. Documentar instalação, primeira execução, atualização e remoção sem excluir dados do usuário.
6. Testar em ambiente limpo e registrar plataforma realmente validada.

## Critérios de aceite

- [ ] Outra máquina/ambiente suportado inicia o aplicativo e carrega modelo.
- [ ] Caminhos não dependem da máquina de desenvolvimento.
- [ ] Distribuição não inclui dados pessoais ou dataset por acidente.
- [ ] Pendências da validação impedem afirmar versão aprovada.

## Validação

Instalar do zero, abrir UI, validar recurso/modelo e diretório de dados; smoke test com câmera quando disponível.

Use dados temporários/sintéticos para verificar lógica quando apropriado e identifique-os como tal. Nunca apresente esses dados como evidência de qualidade do reconhecimento. Não substitua bancos ou amostras reais. Se câmera, dependências, modelo, participantes ou ambiente não estiverem disponíveis, informe quais verificações ficaram pendentes.

## Fora do escopo

Não publicar release, fazer upload público, assinar instalador ou prometer suporte a sistemas não testados.

Não iniciar a próxima task, adicionar requisitos não solicitados, publicar arquivos, executar push ou instalar dependências globalmente. Não remover dados reais. A documentação local mínima e os testes diretamente necessários à entrega estão autorizados; mudanças amplas ficam para suas tasks próprias.

## Encerramento obrigatório

Ao terminar, apresente:

1. O que foi implementado ou documentado nesta task.
2. Lista dos arquivos criados ou alterados e motivo.
3. Comandos/verificações executados e resultados reais.
4. Critérios de aceite cumpridos e pendentes.
5. Bloqueios, decisões humanas ou validações de hardware ainda necessários.

Atualize apenas o estado e os checkboxes desta task com base nas evidências. Use `concluída`, `parcial — validação pendente` ou `bloqueada`, conforme o resultado. Pare depois desse resumo e aguarde nova solicitação. Não marque tasks dependentes como concluídas.
