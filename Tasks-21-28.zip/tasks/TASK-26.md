# TASK-26 — Validar com usuarios e medir desempenho

- **Estado inicial:** não iniciada.
- **Etapa:** 6 de 6.
- **Dependências diretas:** [TASK-25](TASK-25.md), [TASK-14](TASK-14.md), [TASK-23](TASK-23.md)
- **Projeto:** IC-LibrasPython.

## Instrução para o Copilot

Execute somente esta task. Leia este arquivo inteiro, as instruções vigentes do repositório e os arquivos relevantes antes de editar. Consulte as dependências apenas para compreender contratos e verificar entregas; não execute outras tasks automaticamente.

O projeto original contém `main.py`, `database/db.py`, `camera/hand_tracking.py`, `ver_dados.py` e `teste_sqlite.py`. `camera/face_tracking.py`, `funcoes/helpers.py` e `models/model.py` estavam vazios. Na versão inicial há coleta de landmarks com OpenCV/MediaPipe e SQLite, sem classificador próprio. As tasks anteriores podem ter alterado essa estrutura: inspecione o estado atual e reutilize o que já existe.

Se uma dependência obrigatória não estiver implementada ou faltar uma decisão humana necessária, realize apenas o trabalho independente útil desta task, registre precisamente o bloqueio e pare. Não implemente a dependência por conta própria nem declare conclusão. Não peça confirmação para decisões técnicas rotineiras dentro deste escopo.

## Objetivo

Verificar o MVP nas condições e metas aprovadas.

## Arquivos e entregáveis previstos

docs/plano-validacao.md; docs/relatorio-validacao.md; scripts de medição necessários.

Esses caminhos são referências relativas à raiz do projeto. Preserve a organização já adotada por tasks concluídas. Edite somente arquivos necessários para esta entrega e a integração mínima indicada; justifique novos caminhos no resumo final. Não sobrescreva trabalho preexistente nem substitua módulos inteiros sem necessidade.

## Atividades autorizadas

1. Preparar roteiro com pessoas fora do treino, conforme protocolo e disponibilidade.
2. Medir acertos e erros por sinal, rejeições, falsos reconhecimentos e tempo entre finalizar captura e resultado.
3. Registrar equipamento, versões, número de participantes, amostras e condições.
4. Observar uso por teclado, compreensão das mensagens e falhas de interação.
5. Comparar com metas da task 03; separar bloqueadores de melhorias.
6. Se não houver participantes ou hardware, entregar plano e ferramentas, mas manter execução e aceite pendentes.

## Critérios de aceite

- [ ] Resultados vêm de sessões reais documentadas.
- [ ] Relatório informa denominadores e limitações.
- [ ] Aprovação depende das metas e da revisão humana.
- [ ] Não se afirma validação concluída quando só existe plano.

## Validação

Auditar registros e cálculo de métricas; executar roteiro com participantes autorizados. Exige ação humana.

Use dados temporários/sintéticos para verificar lógica quando apropriado e identifique-os como tal. Nunca apresente esses dados como evidência de qualidade do reconhecimento. Não substitua bancos ou amostras reais. Se câmera, dependências, modelo, participantes ou ambiente não estiverem disponíveis, informe quais verificações ficaram pendentes.

## Fora do escopo

Não contactar pessoas, inventar sessões ou mudar metas para acomodar resultados.

Não iniciar a próxima task, adicionar requisitos não solicitados, publicar arquivos, executar push ou instalar dependências globalmente. Não remover dados reais. A documentação local mínima e os testes diretamente necessários à entrega estão autorizados; mudanças amplas ficam para suas tasks próprias.

## Encerramento obrigatório

Ao terminar, apresente:

1. O que foi implementado ou documentado nesta task.
2. Lista dos arquivos criados ou alterados e motivo.
3. Comandos/verificações executados e resultados reais.
4. Critérios de aceite cumpridos e pendentes.
5. Bloqueios, decisões humanas ou validações de hardware ainda necessários.

Atualize apenas o estado e os checkboxes desta task com base nas evidências. Use `concluída`, `parcial — validação pendente` ou `bloqueada`, conforme o resultado. Pare depois desse resumo e aguarde nova solicitação. Não marque tasks dependentes como concluídas.
