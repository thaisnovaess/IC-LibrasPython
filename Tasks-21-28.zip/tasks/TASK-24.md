# TASK-24 — Criar interface de uso

- **Estado inicial:** não iniciada.
- **Etapa:** 5 de 6.
- **Dependências diretas:** [TASK-23](TASK-23.md), [TASK-08](TASK-08.md), [TASK-13](TASK-13.md)
- **Projeto:** IC-LibrasPython.

## Instrução para o Copilot

Execute somente esta task. Leia este arquivo inteiro, as instruções vigentes do repositório e os arquivos relevantes antes de editar. Consulte as dependências apenas para compreender contratos e verificar entregas; não execute outras tasks automaticamente.

O projeto original contém `main.py`, `database/db.py`, `camera/hand_tracking.py`, `ver_dados.py` e `teste_sqlite.py`. `camera/face_tracking.py`, `funcoes/helpers.py` e `models/model.py` estavam vazios. Na versão inicial há coleta de landmarks com OpenCV/MediaPipe e SQLite, sem classificador próprio. As tasks anteriores podem ter alterado essa estrutura: inspecione o estado atual e reutilize o que já existe.

Se uma dependência obrigatória não estiver implementada ou faltar uma decisão humana necessária, realize apenas o trabalho independente útil desta task, registre precisamente o bloqueio e pare. Não implemente a dependência por conta própria nem declare conclusão. Não peça confirmação para decisões técnicas rotineiras dentro deste escopo.

## Objetivo

Permitir operar o MVP sem terminal.

## Arquivos e entregáveis previstos

ui/ ou equivalente; inicialização; documentação de execução.

Esses caminhos são referências relativas à raiz do projeto. Preserve a organização já adotada por tasks concluídas. Edite somente arquivos necessários para esta entrega e a integração mínima indicada; justifique novos caminhos no resumo final. Não sobrescreva trabalho preexistente nem substitua módulos inteiros sem necessidade.

## Atividades autorizadas

1. Escolher uma biblioteca desktop compatível com o ambiente; registrar escolha antes de adicionar dependências.
2. Criar tela com preview, seleção de câmera, estado, iniciar/finalizar captura e resultado.
3. Disponibilizar modo coleta com seleção de sinal e descarte, reutilizando serviços existentes.
4. Dar acesso à revisão existente sem duplicar regras; treinamento pode permanecer comando técnico documentado.
5. Garantir navegação por teclado, foco visível, textos legíveis e estados que não dependam apenas de cor.
6. Manter operações lentas fora do bloqueio da UI e finalizar recursos ao fechar.

## Critérios de aceite

- [ ] Usuário executa reconhecimento sem terminal.
- [ ] Coleta e reconhecimento ficam claramente separados.
- [ ] Erros orientam a próxima ação.
- [ ] Critérios de acessibilidade da task 03 foram verificados.

## Validação

Roteiro manual de abertura, troca de câmera, coleta, reconhecimento, erro e fechamento; testar navegação por teclado.

Use dados temporários/sintéticos para verificar lógica quando apropriado e identifique-os como tal. Nunca apresente esses dados como evidência de qualidade do reconhecimento. Não substitua bancos ou amostras reais. Se câmera, dependências, modelo, participantes ou ambiente não estiverem disponíveis, informe quais verificações ficaram pendentes.

## Fora do escopo

Não criar login, nuvem, aplicativo mobile ou lógica de ML dentro dos widgets.

Não iniciar a próxima task, adicionar requisitos não solicitados, publicar arquivos, executar push ou instalar dependências globalmente. Não remover dados reais. A documentação local mínima e os testes diretamente necessários à entrega estão autorizados; mudanças amplas ficam para suas tasks próprias.

## Encerramento obrigatório

Ao terminar, apresente:

1. O que foi implementado ou documentado nesta task.
2. Lista dos arquivos criados ou alterados e motivo.
3. Comandos/verificações executados e resultados reais.
4. Critérios de aceite cumpridos e pendentes.
5. Bloqueios, decisões humanas ou validações de hardware ainda necessários.

Atualize apenas o estado e os checkboxes desta task com base nas evidências. Use `concluída`, `parcial — validação pendente` ou `bloqueada`, conforme o resultado. Pare depois desse resumo e aguarde nova solicitação. Não marque tasks dependentes como concluídas.
