# TASK-23 — Tratar incerteza e repeticao

- **Estado inicial:** não iniciada.
- **Etapa:** 5 de 6.
- **Dependências diretas:** [TASK-22](TASK-22.md), [TASK-19](TASK-19.md)
- **Projeto:** IC-LibrasPython.

## Instrução para o Copilot

Execute somente esta task. Leia este arquivo inteiro, as instruções vigentes do repositório e os arquivos relevantes antes de editar. Consulte as dependências apenas para compreender contratos e verificar entregas; não execute outras tasks automaticamente.

O projeto original contém `main.py`, `database/db.py`, `camera/hand_tracking.py`, `ver_dados.py` e `teste_sqlite.py`. `camera/face_tracking.py`, `funcoes/helpers.py` e `models/model.py` estavam vazios. Na versão inicial há coleta de landmarks com OpenCV/MediaPipe e SQLite, sem classificador próprio. As tasks anteriores podem ter alterado essa estrutura: inspecione o estado atual e reutilize o que já existe.

Se uma dependência obrigatória não estiver implementada ou faltar uma decisão humana necessária, realize apenas o trabalho independente útil desta task, registre precisamente o bloqueio e pare. Não implemente a dependência por conta própria nem declare conclusão. Não peça confirmação para decisões técnicas rotineiras dentro deste escopo.

## Objetivo

Evitar apresentar toda entrada como um sinal conhecido.

## Arquivos e entregáveis previstos

política de decisão; configuração do pacote; relatório de calibração.

Esses caminhos são referências relativas à raiz do projeto. Preserve a organização já adotada por tasks concluídas. Edite somente arquivos necessários para esta entrega e a integração mínima indicada; justifique novos caminhos no resumo final. Não sobrescreva trabalho preexistente nem substitua módulos inteiros sem necessidade.

## Atividades autorizadas

1. Usar somente validação e exemplos de ausência/fora de vocabulário para definir limiares e regras.
2. Distinguir sem mãos, entrada insuficiente, não reconhecido e candidato aceito.
3. Avaliar softmax e margem como scores não calibrados; registrar como foram escolhidos os critérios.
4. Para modo manual emitir no máximo um resultado por captura e permitir repetição intencional em captura seguinte.
5. Versionar configuração de decisão vinculada ao pacote; reportar trade-off entre rejeição e aceitação incorreta.

## Critérios de aceite

- [ ] Entrada inválida não produz rótulo afirmativo.
- [ ] Critérios têm evidência de validação.
- [ ] Mesmo evento não é emitido repetidamente.
- [ ] Sinal repetido intencionalmente em outra captura não é bloqueado.

## Validação

Verificar estados, bordas dos limiares e duas capturas do mesmo sinal; medir aceitação/rejeição em validação real.

Use dados temporários/sintéticos para verificar lógica quando apropriado e identifique-os como tal. Nunca apresente esses dados como evidência de qualidade do reconhecimento. Não substitua bancos ou amostras reais. Se câmera, dependências, modelo, participantes ou ambiente não estiverem disponíveis, informe quais verificações ficaram pendentes.

## Fora do escopo

Não prometer reconhecimento perfeito de desconhecidos, calibrar com teste ou implementar linguagem/frases.

Não iniciar a próxima task, adicionar requisitos não solicitados, publicar arquivos, executar push ou instalar dependências globalmente. Não remover dados reais. A documentação local mínima e os testes diretamente necessários à entrega estão autorizados; mudanças amplas ficam para suas tasks próprias.

## Encerramento obrigatório

Ao terminar, apresente:

1. O que foi implementado ou documentado nesta task.
2. Lista dos arquivos criados ou alterados e motivo.
3. Comandos/verificações executados e resultados reais.
4. Critérios de aceite cumpridos e pendentes.
5. Bloqueios, decisões humanas ou validações de hardware ainda necessários.

Atualize apenas o estado e os checkboxes desta task com base nas evidências. Use `concluída`, `parcial — validação pendente` ou `bloqueada`, conforme o resultado. Pare depois desse resumo e aguarde nova solicitação. Não marque tasks dependentes como concluídas.
