# TASK-03 — Definir requisitos e critérios do MVP

- **Estado inicial:** não iniciada.
- **Etapa:** 1 de 6.
- **Dependências diretas:** [TASK-01](TASK-01.md), [TASK-02](TASK-02.md)
- **Projeto:** IC-LibrasPython.

## Instrução para o Copilot

Execute somente esta task. Leia este arquivo inteiro, as instruções vigentes do repositório e os arquivos relevantes antes de editar. Consulte as dependências apenas para compreender contratos e verificar entregas; não execute outras tasks automaticamente.

O projeto original contém `main.py`, `database/db.py`, `camera/hand_tracking.py`, `ver_dados.py` e `teste_sqlite.py`. `camera/face_tracking.py`, `funcoes/helpers.py` e `models/model.py` estavam vazios. Na versão inicial há coleta de landmarks com OpenCV/MediaPipe e SQLite, sem classificador próprio. As tasks anteriores podem ter alterado essa estrutura: inspecione o estado atual e reutilize o que já existe.

Se uma dependência obrigatória não estiver implementada ou faltar uma decisão humana necessária, realize apenas o trabalho independente útil desta task, registre precisamente o bloqueio e pare. Não implemente a dependência por conta própria nem declare conclusão. Não peça confirmação para decisões técnicas rotineiras dentro deste escopo.

## Objetivo

Estabelecer comportamento observável e critérios de entrega.

## Arquivos e entregáveis previstos

docs/requisitos.md.

Esses caminhos são referências relativas à raiz do projeto. Preserve a organização já adotada por tasks concluídas. Edite somente arquivos necessários para esta entrega e a integração mínima indicada; justifique novos caminhos no resumo final. Não sobrescreva trabalho preexistente nem substitua módulos inteiros sem necessidade.

## Atividades autorizadas

1. Descrever fluxos de coleta, revisão, treinamento e reconhecimento de um sinal por vez.
2. Adotar captura de início e fim manuais para o primeiro MVP; registrar detecção automática como evolução.
3. Definir comportamento sem mãos, resultado incerto, falha de câmera e encerramento.
4. Propor metas mensuráveis de F1 por classe, falsos reconhecimentos, tempo de resposta, equipamento e condições de avaliação; pedir aprovação dos valores.
5. Registrar critérios de acessibilidade da interface: teclado, foco visível e estados descritos em texto.

## Critérios de aceite

- [ ] Requisitos possuem IDs e critérios observáveis.
- [ ] Metas estão aprovadas ou marcadas como pendentes.
- [ ] Limites do reconhecimento e modo de interação definidos.

## Validação

Revisar cada requisito para que possa ser verificado nas tasks 24 e 26.

Use dados temporários/sintéticos para verificar lógica quando apropriado e identifique-os como tal. Nunca apresente esses dados como evidência de qualidade do reconhecimento. Não substitua bancos ou amostras reais. Se câmera, dependências, modelo, participantes ou ambiente não estiverem disponíveis, informe quais verificações ficaram pendentes.

## Fora do escopo

Não implementar funcionalidades nem prometer métricas sem medir.

Não iniciar a próxima task, adicionar requisitos não solicitados, publicar arquivos, executar push ou instalar dependências globalmente. Não remover dados reais. A documentação local mínima e os testes diretamente necessários à entrega estão autorizados; mudanças amplas ficam para suas tasks próprias.

## Encerramento obrigatório

Ao terminar, apresente:

1. O que foi implementado ou documentado nesta task.
2. Lista dos arquivos criados ou alterados e motivo.
3. Comandos/verificações executados e resultados reais.
4. Critérios de aceite cumpridos e pendentes.
5. Bloqueios, decisões humanas ou validações de hardware ainda necessários.

Atualize apenas o estado e os checkboxes desta task com base nas evidências. Use `concluída`, `parcial — validação pendente` ou `bloqueada`, conforme o resultado. Pare depois desse resumo e aguarde nova solicitação. Não marque tasks dependentes como concluídas.
