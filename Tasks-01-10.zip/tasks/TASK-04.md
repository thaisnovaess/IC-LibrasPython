# TASK-04 — Padronizar o ambiente

- **Estado inicial:** não iniciada.
- **Etapa:** 2 de 6.
- **Dependências diretas:** [TASK-03](TASK-03.md)
- **Projeto:** IC-LibrasPython.

## Instrução para o Copilot

Execute somente esta task. Leia este arquivo inteiro, as instruções vigentes do repositório e os arquivos relevantes antes de editar. Consulte as dependências apenas para compreender contratos e verificar entregas; não execute outras tasks automaticamente.

O projeto original contém `main.py`, `database/db.py`, `camera/hand_tracking.py`, `ver_dados.py` e `teste_sqlite.py`. `camera/face_tracking.py`, `funcoes/helpers.py` e `models/model.py` estavam vazios. Na versão inicial há coleta de landmarks com OpenCV/MediaPipe e SQLite, sem classificador próprio. As tasks anteriores podem ter alterado essa estrutura: inspecione o estado atual e reutilize o que já existe.

Se uma dependência obrigatória não estiver implementada ou faltar uma decisão humana necessária, realize apenas o trabalho independente útil desta task, registre precisamente o bloqueio e pare. Não implemente a dependência por conta própria nem declare conclusão. Não peça confirmação para decisões técnicas rotineiras dentro deste escopo.

## Objetivo

Tornar a instalação reproduzível no ambiente alvo.

## Arquivos e entregáveis previstos

requirements.txt; requirements-dev.txt se necessário; docs/ambiente.md.

Esses caminhos são referências relativas à raiz do projeto. Preserve a organização já adotada por tasks concluídas. Edite somente arquivos necessários para esta entrega e a integração mínima indicada; justifique novos caminhos no resumo final. Não sobrescreva trabalho preexistente nem substitua módulos inteiros sem necessidade.

## Atividades autorizadas

1. Identificar Python, sistema e API MediaPipe efetivamente utilizados; o código original usa mp.solutions.hands.
2. Criar ambiente virtual isolado e validar combinação compatível de MediaPipe, NumPy e uma única distribuição OpenCV com GUI.
3. Registrar versões validadas e comandos para Windows e, se testado, outros sistemas.
4. Verificar imports, acesso à classe Hands e consistência das dependências; documentar limites da verificação sem webcam.

## Critérios de aceite

- [ ] Dependências da coleta estão registradas com versões reproduzíveis.
- [ ] Comandos de instalação e verificação documentados.
- [ ] Plataformas testadas estão separadas das não testadas.

## Validação

Instalar em ambiente limpo, executar pip check e smoke test de imports; não declarar teste gráfico sem realizá-lo.

Use dados temporários/sintéticos para verificar lógica quando apropriado e identifique-os como tal. Nunca apresente esses dados como evidência de qualidade do reconhecimento. Não substitua bancos ou amostras reais. Se câmera, dependências, modelo, participantes ou ambiente não estiverem disponíveis, informe quais verificações ficaram pendentes.

## Fora do escopo

Não migrar a API do MediaPipe, instalar bibliotecas globais ou adicionar PyTorch antes da task 17.

Não iniciar a próxima task, adicionar requisitos não solicitados, publicar arquivos, executar push ou instalar dependências globalmente. Não remover dados reais. A documentação local mínima e os testes diretamente necessários à entrega estão autorizados; mudanças amplas ficam para suas tasks próprias.

## Encerramento obrigatório

Ao terminar, apresente:

1. O que foi implementado ou documentado nesta task.
2. Lista dos arquivos criados ou alterados e motivo.
3. Comandos/verificações executados e resultados reais.
4. Critérios de aceite cumpridos e pendentes.
5. Bloqueios, decisões humanas ou validações de hardware ainda necessários.

Atualize apenas o estado e os checkboxes desta task com base nas evidências. Use `concluída`, `parcial — validação pendente` ou `bloqueada`, conforme o resultado. Pare depois desse resumo e aguarde nova solicitação. Não marque tasks dependentes como concluídas.
